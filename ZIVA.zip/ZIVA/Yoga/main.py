from fastapi import FastAPI, HTTPException, Request
from typing import Union
from typing import Literal
from fastapi.responses import HTMLResponse
from Yoga.Yoga_ranking import rank_yoga_workouts, read_criteria
from fastapi.responses import JSONResponse
from fastapi.templating import Jinja2Templates
import os


print("Current Working Directory:", os.getcwd())

app = FastAPI()

templates_yoga = Jinja2Templates(directory="templates")

folder_path_yoga = "/Users/chaitanyavishnur/Documents/ZIVA/Yoga/Yoga_txt_files"
criteria_file_yoga = "/Users/chaitanyavishnur/Documents/ZIVA/Yoga/Yoga_criteria.json"
criteria_file_yoga = read_criteria(criteria_file_yoga)
sorted_files = rank_yoga_workouts(folder_path_yoga, criteria_file_yoga)
top_files = sorted_files
# Prepare data for HTML template
top_files_details_yoga = []
for file_details in top_files[:3]:
    top_files_details_yoga.append({
        'file_name': file_details['file_name'],
        'score': file_details['score'],
        'workout_name': file_details['workout_name'],
        'workout_time': file_details['workout_time'],
        'number_of_yogas': file_details['number_of_yogas'],
        'justification': file_details['justification']
     })
all_files_details_yoga = []
for file_details in top_files:
    all_files_details_yoga.append({
        'file_name': file_details['file_name'],
        'score': file_details['score'],
        'workout_name': file_details['workout_name'],
        'workout_time': file_details['workout_time'],
        'number_of_yogas': file_details['number_of_yogas'],
        'file_content': file_details['file_content']
    })

@app.get("/")
def root():
    return {"message": "ZIVA"}

@app.get("/user_profile")
def user_profile():
    return {"message": "user_profile"}

@app.get("/Yoga", response_class=HTMLResponse)
def Yoga(request: Request):
    return templates_yoga.TemplateResponse("Yoga_Ziva.html", {
            "request": request,
            "top_files_details": top_files_details,
            "all_files_details": all_files_details
    })

@app.get("/Exercise")
def Exercise():
    return {"message": "Exercise"}

@app.get("/GYM_Workouts")
def GYM_Workouts():
   return {"message": "GYM Workouts"}

@app.get("/CalorieQuest")
def CalorieQuest():
    return {"message": "CalorieQuest"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
