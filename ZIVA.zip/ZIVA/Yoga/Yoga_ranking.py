import os
import json
import re


# Function to read criteria from the criteria file
def read_criteria(Yoga_criteria):
    with open(Yoga_criteria, 'r') as file:
        criteria = json.load(file)
    return criteria

def extract_total_workout_time(file_content):
    total_workout_time_pattern = re.compile(r'Total Time: (\d+) minutes')
    match = total_workout_time_pattern.search(file_content)
    if match:
        return int(match.group(1))
    return None

def extract_total_number_of_workouts(file_content):
    total_calories_burned_pattern = re.compile(r'Total Yoga Workouts: (\d+)')
    match = total_calories_burned_pattern.search(file_content)
    if match:
        return int(match.group(1))
    return None

def rank_yoga_workouts(folder_path, criteria):
    files = os.listdir(folder_path)
    ranked_files = []

    for file_name in files:
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            file_content = file.read()

        workout_time = extract_total_workout_time(file_content)
        number_of_yogas = extract_total_number_of_workouts(file_content)
        if workout_time is not None and number_of_yogas is not None:
            workout_time_score = 0
            number_of_yogas_score = 0

            for key, weight in criteria["Total Workout Time"].items():
                criteria_value = int(re.search(r'\d+', key).group())
                if workout_time <= criteria_value:
                    workout_time_score = weight
                    break

            for key, weight in criteria["Total Yoga Workouts"].items():
                criteria_value = int(re.search(r'\d+', key).group())
                if number_of_yogas <= criteria_value:
                    number_of_yogas_score = weight
                    break

            total_score = workout_time_score + number_of_yogas_score
            if number_of_yogas == 20:
                justification = "High workout intensity"
            if number_of_yogas < 20 and number_of_yogas >= 16:
                justification = "Moderate workout intensity"
            elif number_of_yogas < 16:
                justification = "Low workout intensity"
            ranked_files.append({
                'file_name': file_name,
                'score': total_score,
                'workout_name': extract_workout_name(file_content),
                'workout_time': workout_time,
                'number_of_yogas': number_of_yogas,
                'file_content': file_content,
                'justification':justification
            })

    sorted_files = sorted(ranked_files, key=lambda x: x['score'], reverse=True)
    return sorted_files

def extract_workout_name(file_content):
    workout_name_pattern = re.compile(r'name:\s*(.*)', re.IGNORECASE)
    match = workout_name_pattern.search(file_content)
    return match.group(1) if match else "Unknown Workout"

def print_all_files(sorted_files):
    All_files = "\nAll Files along with their scores:"
    for file_name, score in sorted_files:
        All_files += f"\n{file_name} - Score: {score}"
    return All_files


