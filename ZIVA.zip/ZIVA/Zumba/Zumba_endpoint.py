from fastapi import FastAPI
from typing import List
from fastapi.responses import HTMLResponse
import os
import re

app = FastAPI()

# Define the directory containing the video files and the criteria file
directory_path = "/Users/usha/Library/Mobile Documents/com~apple~CloudDocs/Data Science/Data wrangling/ProjectDW/Zumba/ZUMBA TXT FILES"
criteria_file_path = "/Users/usha/Library/Mobile Documents/com~apple~CloudDocs/Data Science/Data wrangling/ProjectDW/Zumba/Ranking_criteria.txt"


# A function to read the ranking criteria from the flat file
def read_ranking_criteria(criteria_file_path):
    criteria = {}
    with open(criteria_file_path, 'r', encoding='utf-8') as file:
        for line in file:
            if ': ' in line:
                key, value = line.strip().split(': ')
                criteria[key] = float(value)
            else:
                # If a line does not contain the expected key-value format, skip it
                print(f"Skipping line in criteria file: {line.strip()}")
    return criteria


# Read and parse the ranking criteria from the flat file
ranking_criteria = read_ranking_criteria(criteria_file_path)


# A function to parse the duration from the text
def parse_duration(duration_str):
    match = re.match(r"(\d+) mins (\d+) sec", duration_str)
    if match:
        minutes = int(match.group(1))
        seconds = int(match.group(2))
        return minutes + seconds / 60
    return 0


# A function to calculate the score for a video based on the criteria
def calculate_video_score(views, duration, description):
    score = views * ranking_criteria['Views weight']
    score += duration * ranking_criteria['Duration weight']
    keywords = ['high rate', 'fast', 'tough', 'advanced', 'intermediate', 'hard']
    for keyword in keywords:
        if keyword in description.lower():
            score += ranking_criteria.get(f'{keyword} weight', 0)
    return score


# A function to rank the videos
def rank_videos(directory_path):
    videos = []
    for filename in os.listdir(directory_path):
        if filename.lower().endswith('.txt'):
            with open(os.path.join(directory_path, filename), 'r', encoding='utf-8') as file:
                content = file.read()
                views_match = re.search(r'Views: (\d+)', content)
                duration_match = re.search(r'Duration of the video: (\d+) mins (\d+) sec', content)
                title_match = re.search(r'Title: (.+)', content)
                description_match = re.search(r'Description: (.+)', content)

                if views_match and duration_match and title_match and description_match:
                    views = int(views_match.group(1))
                    duration = parse_duration(duration_match.group(0))
                    title = title_match.group(1)
                    description = description_match.group(1)
                    score = calculate_video_score(views, duration, description)
                    videos.append({
                        'title': title,
                        'score': score,

                    })

    # Sort the list of videos by score in descending order
    videos.sort(key=lambda x: x['score'], reverse=True)
    return videos


# Define a FastAPI endpoint to retrieve the top three ranked videos
@app.get("/ranked-zumba-videos/", response_model=List[dict])
async def get_ranked_videos():
    ranked_videos = rank_videos(directory_path)
    # Return the top three videos along with their titles and reasons for their score
    return ranked_videos[:3]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("Zumba_endpoint:app", host="127.0.0.1", port=8000, reload=True)